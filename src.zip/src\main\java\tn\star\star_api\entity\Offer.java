package tn.star.star_api.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "offer")
@Data
@NoArgsConstructor
public class Offer {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id")
    private OfferCategory category;

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "max_participants", nullable = false)
    private Integer maxParticipants = 0;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price = BigDecimal.ZERO;

    @Column(name = "document_needed", length = 255)
    private String documentNeeded;

    @Column(name = "payment_method", length = 100)
    private String paymentMethod = "free";

    // ── Binary image storage ──────────────────────────────
    // LAZY = only loaded when explicitly accessed (not in list queries)
    // This prevents loading MBs of image data for every offer in the list
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "cover_image", columnDefinition = "BYTEA")
    private byte[] coverImage;

    @Column(name = "cover_image_type", length = 20)
    private String coverImageType;

    // Gallery stored as JSON array of base64 strings in TEXT column
    @Column(name = "images", columnDefinition = "TEXT")
    private String images;

    @Column(name = "images_types", columnDefinition = "TEXT")
    private String imagesTypes;

    // Flag to know if cover exists without loading the binary
    // We derive this from coverImageType being non-null
    public boolean hasCoverImage() {
        return coverImageType != null;
    }

    public boolean hasGallery() {
        return images != null && !images.isEmpty();
    }

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    @Column(nullable = false)
    private OfferStatus status = OfferStatus.active;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "created_by")
    private AssociationMember createdBy;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "created_by_admin")
    private User createdByAdmin;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    public enum OfferStatus {
        active, suggested, cancelled, finished
    }
}
