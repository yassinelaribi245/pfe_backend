package tn.star.star_api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import tn.star.star_api.entity.Offer;
import tn.star.star_api.repository.OfferRepository;

import java.util.*;

@RestController
@RequestMapping("/api/images")
@RequiredArgsConstructor
public class ImageController {

    private final OfferRepository offerRepository;
    private final ObjectMapper    mapper = new ObjectMapper();

    // ── POST /api/images/upload-base64 ────────────────────
    @PostMapping("/upload-base64")
    public ResponseEntity<?> uploadBase64(
            @RequestBody Map<String, Object> body) {
        try {
            String offerId = (String) body.getOrDefault("offerId", "temp");

            @SuppressWarnings("unchecked")
            List<Map<String, String>> files =
                (List<Map<String, String>>) body.get("files");

            if (files == null || files.isEmpty()) {
                return ResponseEntity.badRequest().body(
                    Map.of("message", "Aucun fichier fourni"));
            }

            for (Map<String, String> f : files) {
                String data = f.get("data");
                if (data == null) continue;
                if (data.contains(",")) data = data.split(",")[1];
                if (Base64.getDecoder().decode(data).length
                        > 5 * 1024 * 1024) {
                    return ResponseEntity.badRequest().body(
                        Map.of("message", "Max 5MB par image"));
                }
            }

            List<String> urls = new ArrayList<>();
            for (int i = 0; i < files.size(); i++) {
                if (i == 0) {
                    urls.add("/api/images/" + offerId + "/cover");
                } else {
                    urls.add("/api/images/" + offerId
                        + "/gallery/" + (i - 1));
                }
            }

            return ResponseEntity.ok(Map.of(
                "urls",  urls,
                "files", files
            ));

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(
                Map.of("message", "Erreur: " + e.getMessage()));
        }
    }

    // ── GET /api/images/{offerId}/cover ───────────────────
    @Transactional(readOnly = true)
    @GetMapping("/{offerId}/cover")
    public ResponseEntity<byte[]> getCover(
            @PathVariable String offerId) {

        UUID id;
        try { id = UUID.fromString(offerId); }
        catch (Exception e) {
            return ResponseEntity.notFound().build();
        }

        // Use a projection query to load ONLY the binary column
        // within this transaction — avoids lazy load issues
        Offer offer = offerRepository.findById(id).orElse(null);
        if (offer == null) {
            return ResponseEntity.notFound().build();
        }

        byte[] data = offer.getCoverImage();
        if (data == null || data.length == 0) {
            return ResponseEntity.notFound().build();
        }

        String ct = offer.getCoverImageType() != null
            ? offer.getCoverImageType() : "image/jpeg";

        return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(ct))
            .cacheControl(CacheControl.noStore())
            .body(data);
    }

    // ── GET /api/images/{offerId}/gallery/{index} ─────────
    @Transactional(readOnly = true)
    @GetMapping("/{offerId}/gallery/{index}")
    public ResponseEntity<byte[]> getGalleryImage(
            @PathVariable String offerId,
            @PathVariable int index) {

        UUID id;
        try { id = UUID.fromString(offerId); }
        catch (Exception e) {
            return ResponseEntity.notFound().build();
        }

        Offer offer = offerRepository.findById(id).orElse(null);
        if (offer == null || offer.getImages() == null) {
            return ResponseEntity.notFound().build();
        }

        try {
            List<?> images = mapper.readValue(
                offer.getImages(), List.class);
            List<?> types  = offer.getImagesTypes() != null
                ? mapper.readValue(offer.getImagesTypes(), List.class)
                : Collections.emptyList();

            if (index < 0 || index >= images.size()) {
                return ResponseEntity.notFound().build();
            }

            String b64 = (String) images.get(index);
            if (b64.contains(",")) b64 = b64.split(",")[1];
            byte[] bytes = Base64.getDecoder().decode(b64);

            String ct = index < types.size()
                ? (String) types.get(index) : "image/jpeg";

            return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(ct))
                .cacheControl(CacheControl.noStore())
                .body(bytes);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}

@RestController
@RequestMapping("/api/images")
@RequiredArgsConstructor
public class ImageController {

    private final OfferRepository offerRepository;
    private final ObjectMapper    mapper = new ObjectMapper();

    // ── POST /api/images/upload-base64 ────────────────────
    // Body: { "offerId": "uuid-or-temp",
    //         "files": [{"name":"x.jpg","data":"base64..."}] }
    //
    // Returns: { "urls": ["/api/images/{offerId}/cover",
    //                     "/api/images/{offerId}/gallery/0", ...] }
    //
    // When offerId = "temp" we just echo back a temp reference.
    // The real saving happens in OfferService.createOffer /
    // updateOffer via the base64 data stored in the request.
    @PostMapping("/upload-base64")
    public ResponseEntity<?> uploadBase64(
            @RequestBody Map<String, Object> body) {
        try {
            String offerId = (String) body.getOrDefault("offerId", "temp");

            @SuppressWarnings("unchecked")
            List<Map<String, String>> files =
                (List<Map<String, String>>) body.get("files");

            if (files == null || files.isEmpty()) {
                return ResponseEntity.badRequest().body(
                    Map.of("message", "Aucun fichier fourni"));
            }

            // Validate sizes
            for (Map<String, String> f : files) {
                String data = f.get("data");
                if (data == null) continue;
                if (data.contains(",")) data = data.split(",")[1];
                if (Base64.getDecoder().decode(data).length
                        > 5 * 1024 * 1024) {
                    return ResponseEntity.badRequest().body(
                        Map.of("message", "Max 5MB par image"));
                }
            }

            // Build URL references — actual bytes travel
            // with the offer creation/update request
            List<String> urls = new ArrayList<>();
            for (int i = 0; i < files.size(); i++) {
                if (i == 0) {
                    urls.add("/api/images/" + offerId + "/cover");
                } else {
                    urls.add("/api/images/" + offerId
                        + "/gallery/" + (i - 1));
                }
            }

            // Also return the raw base64 data so OfferService
            // can store it directly in the DB
            return ResponseEntity.ok(Map.of(
                "urls",  urls,
                "files", files  // pass through for DB storage
            ));

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(
                Map.of("message", "Erreur: " + e.getMessage()));
        }
    }

    // ── GET /api/images/{offerId}/cover ───────────────────
    @GetMapping("/{offerId}/cover")
    public ResponseEntity<byte[]> getCover(
            @PathVariable String offerId) {

        UUID id;
        try { id = UUID.fromString(offerId); }
        catch (Exception e) {
            return ResponseEntity.notFound().build();
        }

        Offer offer = offerRepository.findById(id).orElse(null);
        if (offer == null || offer.getCoverImage() == null) {
            return ResponseEntity.notFound().build();
        }

        String ct = offer.getCoverImageType() != null
            ? offer.getCoverImageType() : "image/jpeg";

        return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(ct))
            .cacheControl(CacheControl.noStore())
            .body(offer.getCoverImage());
    }

    // ── GET /api/images/{offerId}/gallery/{index} ─────────
    @GetMapping("/{offerId}/gallery/{index}")
    public ResponseEntity<byte[]> getGalleryImage(
            @PathVariable String offerId,
            @PathVariable int index) {

        UUID id;
        try { id = UUID.fromString(offerId); }
        catch (Exception e) {
            return ResponseEntity.notFound().build();
        }

        Offer offer = offerRepository.findById(id).orElse(null);
        if (offer == null || offer.getImages() == null) {
            return ResponseEntity.notFound().build();
        }

        try {
            // images stored as JSON array of base64 strings
            List<?> images = mapper.readValue(
                offer.getImages(), List.class);
            List<?> types  = offer.getImagesTypes() != null
                ? mapper.readValue(offer.getImagesTypes(), List.class)
                : Collections.emptyList();

            if (index < 0 || index >= images.size()) {
                return ResponseEntity.notFound().build();
            }

            String b64 = (String) images.get(index);
            if (b64.contains(",")) b64 = b64.split(",")[1];
            byte[] bytes = Base64.getDecoder().decode(b64);

            String ct = index < types.size()
                ? (String) types.get(index) : "image/jpeg";

            return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(ct))
                .cacheControl(CacheControl.noStore())
                .body(bytes);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
